Subcommands
===========

Subcommands permit the user to modify theme in mass. 

add-event
^^^^^^^^^

.. include:: ../tools/naivecalendar-add-event
   :start-line: 5
   :end-line: 22

---------------------------------

update
^^^^^^

.. include:: ../tools/naivecalendar-update
   :start-line: 38
   :end-line: 54

