Build
=====

.. include:: ../README.rst
   :start-after: .. _dev:
   :end-before: .. _start-link:

