
.. include:: ../README.rst
   :start-after: .. _usage:
   :end-before: .. _customize:
