License
=======

.. include:: ../LICENSE

