
.. include:: ../README.rst
   :end-before: .. _contents:

.. include:: ../README.rst
   :start-after: .. _start-link:

.. toctree::
   :maxdepth: 2

   install  
   usage
   subcommands
   customize
   files
   module
   themes
   build
   license
