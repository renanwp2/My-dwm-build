Install
=======

.. include:: ../README.rst
   :start-after: .. _installation:
   :end-before: .. _usage:

.. include:: ../README.rst
   :start-after: .. _start-link:





